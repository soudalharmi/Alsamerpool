'use client'
import { useCallback, useEffect, useRef, useState } from 'react'
import { loadStripe } from '@stripe/stripe-js'
import { Elements, PaymentElement, useElements, useStripe } from '@stripe/react-stripe-js'
import { sb } from '@/lib/supabase-browser'
import { useLang } from '@/components/Lang'
import { fmt } from '@/lib/money'
const stripeP = process.env.NEXT_PUBLIC_STRIPE_PK ? loadStripe(process.env.NEXT_PUBLIC_STRIPE_PK) : null

function PayForm({ onDone, t }: any) {
  const stripe = useStripe(), els = useElements(); const [busy, setBusy] = useState(false), [err, setErr] = useState('')
  const go = async () => {
    if (!stripe || !els) return; setBusy(true)
    const { error } = await stripe.confirmPayment({ elements: els, redirect: 'if_required' })
    setBusy(false); error ? setErr(error.message || '') : onDone()
  }
  return (<><PaymentElement />{err && <p className="muted" style={{ color: 'var(--red)' }}>{err}</p>}
    <button className="btn gold full" disabled={busy} onClick={go}>{t('pay_now')}</button></>)
}

export default function Live({ slug }: { slug: string }) {
  const { t, lang } = useLang(); const db = sb()
  const [vendor, setVendor] = useState<any>(null), [item, setItem] = useState<any>(null), [bids, setBids] = useState<any[]>([])
  const [user, setUser] = useState<any>(null), [me, setMe] = useState<any>(null), [amount, setAmount] = useState(0)
  const [modal, setModal] = useState<'' | 'choose' | 'support' | 'pay'>(''), [secret, setSecret] = useState(''), [msg, setMsg] = useState(''), [busy, setBusy] = useState(false)
  const [phone, setPhone] = useState(''), [code, setCode] = useState(''), [sent, setSent] = useState(false), [name, setName] = useState('')
  const idem = useRef('')

  const load = useCallback(async () => {
    const { data: v } = await db.from('vendors').select('*').eq('slug', slug).maybeSingle(); setVendor(v); if (!v) return
    const { data: its } = await db.from('auction_items').select('*').eq('vendor_id', v.id).in('status', ['live', 'paused']).order('status').limit(1)
    const it = its?.[0] || null; setItem(it)
    if (it) { const { data: b } = await db.from('bids').select('*').eq('item_id', it.id).order('created_at', { ascending: false }).limit(15); setBids(b || []) } else setBids([])
    const { data: { user: u } } = await db.auth.getUser(); setUser(u)
    if (u) { const { data: m } = await db.from('bidders').select('*').eq('vendor_id', v.id).eq('user_id', u.id).maybeSingle(); setMe(m) }
  }, [slug])
  useEffect(() => { load() }, [load])
  useEffect(() => {
    if (!vendor) return
    const f = `vendor_id=eq.${vendor.id}`
    const ch = db.channel('live-' + vendor.id)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'auction_items', filter: f }, load)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'bids', filter: f }, load)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'bidders', filter: f }, load).subscribe()
    return () => { db.removeChannel(ch) }
  }, [vendor?.id, load])

  const hasLeader = !!item?.leader_bidder_id
  const next = item ? (hasLeader ? item.current_price_fils + item.increment_fils : item.start_price_fils) : 0
  useEffect(() => { setAmount(a => Math.max(a, next)) }, [next])
  const isLeader = me && item?.leader_bidder_id === me.id
  const canBid = me?.status === 'approved' && item?.status === 'live' && !isLeader
  const canSupport = canBid && hasLeader
  const err = (c: string) => t(c) === c ? t('GENERIC') : t(c)
  const post = async (url: string, body: any) => { const r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }); return r.json() }
  const key = () => (idem.current ||= crypto.randomUUID())

  const bid = async () => {
    setBusy(true); const j = await post('/api/bid', { itemId: item.id, amountFils: amount, idem: key() }); setBusy(false); idem.current = ''
    setModal(''); setMsg(j.error ? err(j.error) : t('bid_ok')); load()
  }
  const support = async () => {
    setBusy(true); const j = await post('/api/support', { itemId: item.id, newPriceFils: amount, idem: key() }); setBusy(false)
    if (j.error) { idem.current = ''; setModal(''); return setMsg(err(j.error)) }
    setSecret(j.clientSecret); setModal('pay')
  }
  const sendCode = async () => { const { error } = await db.auth.signInWithOtp({ phone }); error ? setMsg(error.message) : setSent(true) }
  const verify = async () => { const { error } = await db.auth.verifyOtp({ phone, token: code, type: 'sms' }); error ? setMsg(error.message) : load() }
  const join = async () => { const { error } = await db.from('bidders').insert({ vendor_id: vendor.id, user_id: user.id, name }); error ? setMsg(error.message) : load() }
  useEffect(() => { if (msg) { const x = setTimeout(() => setMsg(''), 4000); return () => clearTimeout(x) } }, [msg])

  if (!vendor) return <main className="wrap"><div className="empty">…</div></main>
  const contrib = amount - (item?.current_price_fils || 0)
  return (
    <main className="wrap" style={{ maxWidth: 560 }}>
      <div className="row section"><h2 style={{ margin: 0 }}>{vendor.name}</h2>{vendor.logo_url && <img src={vendor.logo_url} height={40} alt="" />}</div>
      <div className="card section">
        {!item ? <div className="empty">{t('no_item')}</div> : (<>
          <div className="product">
            <div className="product-img">{item.image_url ? <img src={item.image_url} alt={item.name} /> : '📿'}</div>
            <div><h3>{item.name}</h3><div className="muted">{item.description}</div>
              <div className="muted" style={{ marginTop: 8 }}>{t('start_price')}: {fmt(item.start_price_fils, lang)}</div></div>
          </div>
          <div className="row" style={{ marginTop: 14 }}><span className="muted">{t('current_bid')}</span>{item.status === 'paused' && <span className="pill gold">{t('paused')}</span>}</div>
          <div className="price">{fmt(item.current_price_fils, lang)}</div>
          {hasLeader && <div className="muted">{t('leader')}: <b>{item.leader_name}</b></div>}
          {isLeader && <div className="pill green" style={{ display: 'inline-block', marginTop: 8 }}>{t('you_lead')}</div>}
          {canBid && (<>
            <div className="muted" style={{ marginTop: 12 }}>{t('next_bid')}: {fmt(next, lang)}</div>
            <div className="stepper">
              <button className="btn light" onClick={() => setAmount(a => Math.max(next, a - item.increment_fils))}>−</button>
              <input readOnly value={fmt(amount, lang)} />
              <button className="btn light" onClick={() => setAmount(a => a + item.increment_fils)}>+</button>
            </div>
            <button className="btn gold full" onClick={() => setModal(canSupport ? 'choose' : 'support')} style={{ display: canSupport ? 'block' : 'none' }}>{t('bid_now')}</button>
            {!canSupport && <button className="btn gold full" disabled={busy} onClick={bid}>{t('bid_now')}</button>}
          </>)}
        </>)}
      </div>

      {!user && <div className="card section">
        <label>{t('phone')}</label><input dir="ltr" placeholder="+9715XXXXXXXX" value={phone} onChange={e => setPhone(e.target.value)} />
        {!sent ? <button className="btn full" onClick={sendCode}>{t('send_code')}</button> : (<>
          <label>{t('code')}</label><input dir="ltr" value={code} onChange={e => setCode(e.target.value)} />
          <button className="btn full" onClick={verify}>{t('verify')}</button></>)}
      </div>}
      {user && !me && <div className="card section"><label>{t('name')}</label><input value={name} onChange={e => setName(e.target.value)} />
        <button className="btn gold full" disabled={!name.trim()} onClick={join}>{t('request_join')}</button></div>}
      {me?.status === 'pending' && <div className="notice">{t('pending_msg')}</div>}
      {(me?.status === 'rejected' || me?.status === 'suspended') && <div className="notice">{t('rejected_msg')}</div>}

      <div className="card section"><h3>{t('bids')}</h3>
        {bids.length === 0 ? <div className="empty">{t('no_bids')}</div> : <div className="bidlist">{bids.map(b => (
          <div className="bidrow" key={b.id}><strong>{b.bidder_name}</strong><span>{fmt(b.amount_fils, lang)}</span></div>))}</div>}
      </div>
      <div className="card"><h3>{t('rules_title')}</h3><p className="muted">{t('rules_text')}</p></div>

      {modal && item && (
        <div className="modal" onClick={() => !busy && modal !== 'pay' && setModal('')}><div className="sheet" onClick={e => e.stopPropagation()}>
          {modal === 'choose' && (<>
            <h3>{fmt(amount, lang)}</h3>
            <button className="btn gold full" disabled={busy} onClick={bid}>{t('bid_self')}</button>
            <button className="btn full" onClick={() => setModal('support')}>{t('bid_support')}</button>
            <button className="btn light full" onClick={() => setModal('')}>{t('cancel')}</button></>)}
          {modal === 'support' && (<>
            <h3>{t('bid_support')}</h3>
            <div className="kv"><span>{t('beneficiary')}</span><b>{item.leader_name}</b></div>
            <div className="kv"><span>{t('current_price')}</span><b>{fmt(item.current_price_fils, lang)}</b></div>
            <div className="kv"><span>{t('proposed_price')}</span><b>{fmt(amount, lang)}</b></div>
            <div className="kv"><span>{t('your_contrib')}</span><b>{fmt(contrib, lang)}</b></div>
            <p className="muted">{t('support_note')}</p>
            <button className="btn gold full" disabled={busy || contrib <= 0} onClick={support}>{t('confirm_support')} – تأكيد الدعم</button>
            <button className="btn light full" onClick={() => setModal('')}>{t('cancel')}</button></>)}
          {modal === 'pay' && stripeP && (<Elements stripe={stripeP} options={{ clientSecret: secret }}>
            <h3>{fmt(contrib, lang)}</h3>
            <PayForm t={t} onDone={() => { setModal(''); setMsg(t('support_wait')); idem.current = '' }} /></Elements>)}
        </div></div>)}
      {msg && <div className="toast">{msg}</div>}
    </main>
  )
}
